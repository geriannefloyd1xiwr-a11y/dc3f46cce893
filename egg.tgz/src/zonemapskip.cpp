// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Skip via zone maps"); }
int main(){
  announce();
  return lionss_run_workload("zonemapskip");
}
