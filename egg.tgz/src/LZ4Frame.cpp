// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compress LZ4 frame"); }
int main(){
  announce();
  return lionss_run_workload("LZ4Frame");
}
