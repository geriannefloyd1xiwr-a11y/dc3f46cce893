// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Extract i18n messages");
  std::fflush(stdout);
  return lionss_run_workload("I18nExtract");
}
