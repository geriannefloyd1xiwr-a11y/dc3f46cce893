// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Run flash attention v2");
  std::fflush(stdout);
  return lionss_run_workload("flashattn-v2");
}
